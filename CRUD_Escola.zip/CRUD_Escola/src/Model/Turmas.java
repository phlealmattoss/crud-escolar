package Model;

public class Turmas {

    int Id_Turma;
    String Nome_Turma;
    int Ano_Letivo;
    
    public Turmas(int Id_Turma, String Nome_Turma, int Ano_Letivo ) {
        this.Id_Turma = Id_Turma;
        this.Nome_Turma = Nome_Turma;
        this.Ano_Letivo = Ano_Letivo;
    }

    public Turmas(String Nome_Turma, int Ano_Letivo ) {
        this.Nome_Turma = Nome_Turma;
        this.Ano_Letivo = Ano_Letivo;
    }

    public int getId_Turma() {
        return Id_Turma;
    }

    public void setId_Turma(int Id_Turma) {
        this.Id_Turma = Id_Turma;
    }

    public String getNome_Turma() {
        return Nome_Turma;
    }

    public void setNome_Turma(String Nome_Turma) {
        this.Nome_Turma = Nome_Turma;
    }

    public int getAno_Letivo() {
        return Ano_Letivo;
    }

    public void setAno_Letivo(int Ano_Letivo) {
        this.Ano_Letivo = Ano_Letivo;
    }

}
