package Model;

public class Professores {

    int Id_Professor;
    String Nome_Prof;
    String Disciplina;
    String Tel;
    String Email;

    public Professores(int Id_Professor, String Nome_Prof, String Disciplina, String Tel, String Email) {
        this.Id_Professor = Id_Professor;
        this.Nome_Prof = Nome_Prof;
        this.Disciplina = Disciplina;
        this.Tel = Tel;
        this.Email = Email;

    }

    public Professores(String Nome_Prof, String Disciplina, String Tel, String Email, String Endereco) {
        this.Nome_Prof = Nome_Prof;
        this.Disciplina = Disciplina;
        this.Tel = Tel;
        this.Email = Email;
    }

    public int getId_Professor() {
        return Id_Professor;
    }

    public void setId_Professor(int Id_Professor) {
        this.Id_Professor = Id_Professor;
    }

    public String getNome_Prof() {
        return Nome_Prof;
    }

    public void setNome_Prof(String Nome_Prof) {
        this.Nome_Prof = Nome_Prof;
    }

    public String getDisciplina() {
        return Disciplina;
    }

    public void setDisciplina(String Disciplina) {
        this.Disciplina = Disciplina;
    }

    public String getTel() {
        return Tel;
    }

    public void setTel(String Tel) {
        this.Tel = Tel;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

}
