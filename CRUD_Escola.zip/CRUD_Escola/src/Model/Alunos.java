package Model;

public class Alunos {

    int Id_Aluno;
    String Nome_Aluno;
    int Idade;
    String Genero;
    String Nome_Responsavel;
    String Email;
    String Endereco;
    String Tel;

    public Alunos(int Id_Aluno, String Nome_Aluno, int Idade, String Genero, String Nome_Responsavel, String Email, String Endereco, String Tel) {
        this.Id_Aluno = Id_Aluno;
        this.Nome_Aluno = Nome_Aluno;
        this.Idade = Idade;
        this.Genero = Genero;
        this.Nome_Responsavel = Nome_Responsavel;
        this.Email = Email;
        this.Endereco = Endereco;
        this.Tel = Tel;
    }

    public Alunos(String Nome_Aluno, int Idade, String Genero, String Nome_Responsavel, String Email, String Endereco, String Tel) {
        this.Nome_Aluno = Nome_Aluno;
        this.Idade = Idade;
        this.Genero = Genero;
        this.Nome_Responsavel = Nome_Responsavel;
        this.Email = Email;
        this.Endereco = Endereco;
        this.Tel = Tel;
    }

    public int getId_Aluno() {
        return Id_Aluno;
    }

    public void setId_Aluno(int Id_Aluno) {
        this.Id_Aluno = Id_Aluno;
    }

    public String getNome_Aluno() {
        return Nome_Aluno;
    }

    public void setNome_Aluno(String Nome_Aluno) {
        this.Nome_Aluno = Nome_Aluno;
    }

    public int getIdade() {
        return Idade;
    }

    public void setIdade(int Idade) {
        this.Idade = Idade;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    public String getNome_Responsavel() {
        return Nome_Responsavel;
    }

    public void setNome_Responsavel(String Nome_Responsavel) {
        this.Nome_Responsavel = Nome_Responsavel;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String Endereco) {
        this.Endereco = Endereco;
    }

    public String getTel() {
        return Tel;
    }

    public void setTel(String Tel) {
        this.Tel = Tel;
    }

}
