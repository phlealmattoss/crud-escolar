package Controller;

import Conexao.conexao;
import Model.Alunos;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AlunosController {

    public void RegistrarAlunos(Alunos alunos) {
        String sql = "insert into livro(Nome_Aluno, Idade, Genero, Nome_Responsavel, Email, Endereco, Tel) values (?,?,?,?,?,?,?)";

        Connection con = null;
        PreparedStatement pstm = null;

        try {
            con = conexao.createConnection();
            pstm = con.prepareStatement(sql);

            pstm.setString(1, alunos.getNome_Aluno());
            pstm.setInt(2, alunos.getIdade());
            pstm.setString(3, alunos.getGenero());
            pstm.setString(4, alunos.getNome_Responsavel());
            pstm.setString(5, alunos.getEmail());
            pstm.setString(6, alunos.getEndereco());
            pstm.setString(7, alunos.getTel());

            pstm.execute();
            JOptionPane.showMessageDialog(null, "Aluno registrado.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro:" + e);
        }
    }

    public List<Alunos> MostrarAlunos() {
        String sql = "select * from livro";
        List<Alunos> alunos = new ArrayList<>();
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rset = null;
        try {
            con = conexao.createConnection();
            pstm = con.prepareStatement(sql);
            rset = pstm.executeQuery();
            while (rset.next()) {

                Alunos al = new Alunos();
                al.setId_Aluno(rset.getInt("Id_Aluno"));
                al.setNome_Aluno(rset.getString("Nome_Aluno"));
                al.setIdade(rset.getInt("Idade"));
                al.setGenero(rset.getString("Genero"));
                al.setNome_Responsavel(rset.getString("Nome_Responsavel"));
                al.setEmail(rset.getString("Email"));
                al.setEndereco(rset.getString("Endereco"));
                al.setTel(rset.getString("Tel"));

                alunos.add(al);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro:" + e);
        }
        return alunos;
    }

    public void AtualizarAlunos(Alunos alunos) {
        String sql = "update Alunos set Nome_Aluno=?, Idade=?, Genero=?, Nome_Responsavel=?, Email=?, Endereco=?, Tel=?";
        Connection con = null;
        PreparedStatement pstm = null;

        try {
            con = conexao.createConnection();
            pstm = con.prepareStatement(sql);

            pstm.setString(1, alunos.getNome_Aluno());
            pstm.setInt(2, alunos.getIdade());
            pstm.setString(3, alunos.getGenero());
            pstm.setString(4, alunos.getNome_Responsavel());
            pstm.setString(5, alunos.getEmail());
            pstm.setString(6, alunos.getEndereco());
            pstm.setString(7, alunos.getTel());
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Aluno Atualizado");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void DeletarLivro(int id) {
        String sql = "delete from Aluno where Id_Aluno=?";
        Connection con = null;
        PreparedStatement pstm = null;

        try {
            con = conexao.createConnection();
            pstm = con.prepareCall(sql);

            pstm.setInt(1, id);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Aluno Deletado.");
        } catch (Exception e) {
            System.out.println("Erro:" + e);
        }
    }
}
