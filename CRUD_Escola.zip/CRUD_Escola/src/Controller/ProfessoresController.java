package Controller;

import Conexao.conexao;
import Model.Professores;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProfessoresController {

    public void RegistrarProfessores(Professores professores) {
        String sql = "insert into Professores( Nome_Prof, Disciplina, Tel, Email) values (?,?,?,?)";

        Connection con = null;
        PreparedStatement pstm = null;

        try {
            con = conexao.createConnection();
            pstm = con.prepareStatement(sql);

            pstm.setString(1, professores.getNome_Prof());
            pstm.setString(3, professores.getDisciplina());
            pstm.setString(4, professores.getTel());
            pstm.setString(5, professores.getEmail());

            pstm.execute();
            JOptionPane.showMessageDialog(null, "Professor registrado.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro:" + e);
        }
    }

    public List<Professores> MostrarProfessores() {
        String sql = "select * from Professores";
        List<Professores> professores = new ArrayList<>();
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rset = null;
        try {
            con = conexao.createConnection();
            pstm = con.prepareStatement(sql);
            rset = pstm.executeQuery();
            while (rset.next()) {

                Professores pf = new Professores();
                pf.setId_Professor(rset.getInt("Id_Professor"));
                pf.setNome_Prof(rset.getString("Nome_Prof"));
                pf.setDisciplina(rset.getString("Disciplina"));
                pf.setTel(rset.getString("Tel"));
                pf.setEmail(rset.getString("Email"));

                professores.add(pf);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro:" + e);
        }
        return professores;
    }

    public void AtualizarProfessores(Professores professores) {
        String sql = "update Professores set Id_Professor=? ,Nome_Prof=? ,Disciplina=? ,Tel=? ,Email=? ";
        Connection con = null;
        PreparedStatement pstm = null;

        try {
            con = conexao.createConnection();
            pstm = con.prepareStatement(sql);

            pstm.setString(1, professores.getNome_Prof());
            pstm.setString(3, professores.getDisciplina());
            pstm.setString(4, professores.getTel());
            pstm.setString(5, professores.getEmail());
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Professores Atualizado");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void DeletarProfessores(int id) {
        String sql = "delete from Professores where Id_Professor=?";
        Connection con = null;
        PreparedStatement pstm = null;

        try {
            con = conexao.createConnection();
            pstm = con.prepareCall(sql);

            pstm.setInt(1, id);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Professor Deletado.");
        } catch (Exception e) {
            System.out.println("Erro:" + e);
        }
    }
}
